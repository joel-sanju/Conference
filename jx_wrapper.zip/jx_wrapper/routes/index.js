const express = require('express');
const router = express.Router();
const { ensureAuthenticated, forwardAuthenticated } = require('../config/auth');

// Welcome Page 


router.get('/', forwardAuthenticated, (req, res) => res.render('welcome', {data : req.protocol + '://' + req.get('host')}));

// Dashboard
router.get('/dashboard', ensureAuthenticated, (req, res) =>

res.redirect('https://jocon.ml/')
  // res.render('dashboard', {
  //   user: req.user,
  //   data : req.protocol + '://' + req.get('host')
  // })
);

// Features
router.get('/features',  (req, res) =>
  res.render('features', {data : req.protocol + '://' + req.get('host')})
);

// Contact Us
router.get('/contact',  (req, res) =>
  res.render('contact', {data : req.protocol + '://' + req.get('host')})
);

// Pricing
router.get('/pricing',  (req, res) =>
  res.render('pricing', {data : req.protocol + '://' + req.get('host')})
);


// Jitsi
router.get('/meet', ensureAuthenticated, (req, res) => {
    if(req.isAuthenticated()) {
      res.sendFile('index.html', { root: '__dirname/../public/jitxi/'});
    }else {
      res.redirect('/login');
    }
  });

module.exports = router;
